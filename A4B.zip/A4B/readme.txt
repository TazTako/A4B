Inspired by FreeCAD, A4B (Atelier 4 Blender) is an addon attempting to reproduce its interface divided into several  specialised workshops (or atelier).

For using this addon, you must first load the scene provided with it. Launch blender and load the scene called "startup_A4B.blend". It will replace all your screen layout by the new ones (A4B-...) needed by the addon.

Then, you can install the addon Atelier4blender.py (User Prefs > "install from files") and activate it by checking the box.